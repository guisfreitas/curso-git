extras
======
The extras directory contains third-party code that is used
by Git Cola.

Git Cola uses
[sphinx-to-github](https://github.com/michaeljones/sphinx-to-github)
for massaging the output of the
[Sphinx](https://github.com/sphinx-doc/sphinx)-generated documentation.

The license and author information for the
[QtPy](https://github.com/spyder-ide/qtpy) library is included in the
[qtpy/](qtpy) directory.
