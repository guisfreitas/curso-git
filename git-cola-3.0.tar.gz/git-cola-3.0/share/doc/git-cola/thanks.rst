Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Cook
* Aaron Wolf
* Adrien be
* AJ Bagwell
* Alex Chernetz
* Alexander Kozienko
* Alf Eaton
* anderben
* Andreas Sommer
* Andrew Chen
* Audrius Karabanovas
* balping
* Barış ÇELİK
* Barry Roberts
* Boris W
* Ben Boeckel
* Ben Cole
* Benedict Lee
* Benoît Nouyrigat
* Bert Jacobs
* 林博仁 (Lin-Buo-Ren)
* Charles 101
* Christian Jann
* Christopher Meng
* Clément Pit--Claudel
* Daniel Fahlke
* Daniel Jay Haskin
* Daniel Harding
* Daniel King
* Dave Thomas
* David Aguilar
* David LeGare
* David Martínez Martí
* Dawid Drozd
* Dennis Gilmore
* deniz1a
* Dmitry Kann
* Dmitry Pashkevich
* Doug Hoskisson
* Drugoy
* Efimov Vasily
* Eric Drechsel
* Fabio Coatti
* Filip Danilović
* Garoe Dorta
* Geoffrey van Wyk
* geotavros
* `Git Hackers <http://git-scm.com/about>`_
* green-eyed-bear
* Glen Mailer
* Guillaume de Bure
* Guo Yunhe
* Harro Verton
* Igor Galarraga
* Igor Kopach
* Ilya Tumaykin
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jan @hanksoff
* Jan Šilhan
* Jan Tumanov
* Jakub Wilk
* James Geiger
* Javier Rodriguez Cuevas
* Jeff Dagenais
* Jérôme Carretero
* jfessard
* JiCiT
* Johann Schmitz
* Jordan Bedwell
* Josh Taylor
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Kirit Sælensminde
* Kyle Slane
* László Böszörményi
* Leho Kraav
* Lev Zlotin
* Libor Jelinek
* Liviu Cristian Mirea-Ghiban
* Luca Ottaviano
* Łukasz Wojniłowicz
* Luke Bakken
* Maarten Nieber
* Maaaks
* Maciej Filipiak
* Mahmoud Hossam
* Mateusz Kedzior
* Maicon D. Filippsen
* Marcin Mielniczuk
* Marco Costalba
* Markus Heidelberg
* Matěj Šmíd
* Matthew Levine
* Matthias Mailänder
* Micha Rosenbaum
* Michael Geddes
* Michael Homer
* Mickael Albertus
* Mike Hanson
* MikHulk
* Minarto Margoliono
* Myz
* Naraesk
* Nick Todd
* Nicolas Dietrich
* OmegaPhil (Omega Weapon)
* Owen Healy
* Pamela Strucker
* Paolo G. Giarrusso
* Parashurama Rhagdamaziel
* Patrick Browne
* Paul Hildebrandt
* Paul Weingardt
* Paulo Fidalgo
* Pavel Rehak
* Peter Dave Hello
* Peter Júnoš
* Philip Stark
* Pilar Molina Lopez
* Raghavendra Karunanidhi
* Rainer Müller
* Robbert Korving
* Rolando Espinoza La fuente
* Rustam Safin
* Samsul Ma'arif
* Sebastian Brass
* Sergey Leschina
* Srinivasa Nallapati
* Stan Angeloff
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Sven Claussner
* Szymon Judasz
* Taylor Braun-Jones
* Thiemo van Engelen
* Thomas Kiley
* Thomas Kluyver
* Tim Schumacher
* Trevor Alexander
* Ugo Riboni
* Uri Okrent
* Utku Karatas
* Ｖ字龍 (Vdragon)
* Vaibhav Sagar
* Vaiz
* Ved Vyas
* Ville Skyttä
* Virgil Dupras
* Vitor Lobo
* v.paritskiy
* Wolfgang Ocker
* Xieofxie
* Yi EungJun
* Zeioth
* Zhang Han
